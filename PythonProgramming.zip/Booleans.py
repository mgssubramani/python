
# binary values - it can have 2 output values (TRUE and FALSE)
# these boolean values are extremely important in conditional statements

result = 3 < 10

print(type(result))
print(result)
