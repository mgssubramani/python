
# == and is operators
# the == operator compares the values !!!
# IS operator compare the memory locations

a = [10, 'Kevin', True, 35.6]
# b = [10, 'Kevin', True, 35.6]
b = a

name1 = 'Adam Smith'
name2 = 'Adam Smith'

# print(name1 == name2)
print(a is b)
