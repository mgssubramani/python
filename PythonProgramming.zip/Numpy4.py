import numpy as np

# 'i' integers, 'f' floating point numbers, 'S' strings 'uint' unsigned integers if we
# want to represent numbers greater than 0

my_array = np.array(['a', 2, 3])

print(my_array)
