
# arithmetic operators: +, -, *, /

a = 13
b = 3

# // which is the integer division
print(a//b)

# ** exponentiation
print(2**5)

# COMPARISON OPERATORS: ==, <, ...
# == equals operator, != not equals operator

c = 5
d = 5

print(c <= d)

# ASSIGNMENT OPERATORS (=)
# we can combine assignment operators with arithmetic operators
e = 10
e /= 5
print(e)
