
# AND - if both of the operands are TRUE then the condition becomes TRUE

a = 10
b = 5

if a < 20 and b < 10:
    print("The logical operand is TRUE")
else:
    print("The result is FALSE")

# OR logical operator - if any of the operands are TRUE then the condition is TRUE

if a < 20 or b < 10:
    print("The logical operand is TRUE")
else:
    print("The result is FALSE")

# NOT logical operator - reverses the actual logical state of the given variable

c = False

print(not c)
