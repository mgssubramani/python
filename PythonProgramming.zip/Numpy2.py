import numpy as np

nums = np.array([1, 2, 3, 4, 5, 6])

print(nums.shape)


