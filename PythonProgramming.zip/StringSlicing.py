
# we are going to use integers as strings
# th letters will represent indexes as well

s = 'This is just for demonstration purposes!'

# array indexes - random indexes
print(s[1])

# string slicing with the : operator
print(s[:])

# we can define the step size
# if we use positive values for the step size: it means that from left to right
# negative values: from right to left
print(s[::-1])

