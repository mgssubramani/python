

lambda_function = lambda **args: sum(args.values())

print(lambda_function(one=1, three=3, five=5, ten=10))
