
# most of the variables in Python are objects

a = 'Kevin'
b = 10
c = 34.5
d = False

print(isinstance(a, object))
print(isinstance(b, object))
print(isinstance(c, object))
print(isinstance(d, object))
