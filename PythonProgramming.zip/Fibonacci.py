
user_preference = {'username': 'my_user_name', 'password': 'my_password'}


def fib(n):

    a, b = 0, 1

    while a < n:
        print(a)
        a, b = b, a + b
