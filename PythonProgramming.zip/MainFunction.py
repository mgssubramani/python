
def say_hello():
    print('Hello world from a given function...')


if __name__ == '__main__':
    say_hello()
    a = 10
    b = 5
    print(a+b)
