
# enumerate keyword: we can use indexes and the values as well

animals = ['cat', 'dog', 'horse']

for index, value in enumerate(animals):
    print(str(index) + " " + str(value))
