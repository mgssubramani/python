
file = open('new_file', 'a')

file.write('\nThis is going to be a new line in the file ...')

file.close()
